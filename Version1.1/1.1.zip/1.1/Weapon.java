public class Weapon extends MetaGame
{
    private Map map = super.getMap();
    private int damage;
    private int type;
    private int prefab;




}