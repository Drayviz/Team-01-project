public class Turn 
{
/*     private GameState gameState;
    private HumanPlayer humanP;
    private AIPlayer aiP; unnecessary?*/

    private Map map;
    private Entity piece;

    /* Constructor for moves */
    public Turn(Entity pees) 
    {
        if(player.getParty() == 1)
        {
            

        }
        if(player.getParty() == 2)
        {


        }
    }
}

//     /* temp is just to create a duplicate of the map. This is to execute moves on. However, this execution will be passed into GameState to ensure
//     whatever was done was valid, THEN the map will be updated (via GameState) */
//     public Map move(int startLocation, int end, Entity player) { 
//         Map temp = new Map(map); //need Map copy constructor
        
    
//         return temp;
//     }

//     /* Same principle as move() */
//     public Map attack(int startLocation, int end)  //can't keep track of who can get attacked; put this method on hold... 
//     { 
//         Map temp = new Map(map); //need Map copy constructor
       
//                 int dmgDealt = a[1].getAtk(); //attacker's attack stat will be taken to consider how much dmg he'll do
//             }
//         }
//         for (Array b:temp) {
//             if (b[2] == end) { //finds the tile of target...
//                 b[1].setHP(b[1], dmgDealt); //target's HP will be set (refer to Entity.java)
//             }
//         }
//         return temp;
//     }
// }

