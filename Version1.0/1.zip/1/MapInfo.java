public class MapInfo
{
    private int turns;
    private int numenemies;
    private int maptype;
    

    /**
     * @return the maptype
     */
    public int getMaptype() 
    {
        return new Integer(maptype);
    }

    /**
     * @return the numenemies
     */
    public int getNumenemies() 
    {
        return new Integer(numenemies);
    }

    /**
     * @return the turns
     */
    public int getTurns() 
    {
        return new Integer(turns);
    }

    /**
     * @param maptype the maptype to set
     */
    public void setMaptype(int maptype) 
    {
        this.maptype = maptype;
    }

    /**
     * @param numenemies the numenemies to set
     */
    public void setNumenemies(int numenemies) 
    {
        this.numenemies = numenemies;
    }
    
    /**
     * @param turns the turns to set
     */
    public void setTurns(int turns) 
    {
        this.turns = turns;
    }
  

























}