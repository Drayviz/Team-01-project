public class AIPlayer
{
    
    for (Entity e:AIPieces) 
    {
    

    
    {

}