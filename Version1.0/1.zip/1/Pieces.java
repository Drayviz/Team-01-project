import java.util.Scanner;
import java.util.ArrayList;


public class Pieces 
{
    private ArrayList<Entity> humanPieces = new ArrayList<Entity>();
    private ArrayList<Entity> aiPieces = new ArrayList<Entity>();
    private ArrayList<Entity> entityParty = new ArrayList<Entity>();
    private ArrayList<Entity> playerParty = new ArrayList<Entity>();


    public ArrayList<Entity> getHumanPieces() {
        ArrayList<Entity> decoy = new ArrayList<Entity>();
        for (Entity h:humanPieces) {
            decoy.add(new Entity(h));
        }
        return decoy;
    }
    
    public ArrayList<Entity> getAIPieces() {
        ArrayList<Entity> decoy = new ArrayList<Entity>();
        for (Entity e:aiPieces) {
            decoy.add(new Entity(e));
        }
        return decoy;
    }

    public ArrayList<Entity> getEntityParty() {
        ArrayList<Entity> decoy = new ArrayList<Entity>();
        for (Entity e:entityParty) {
            decoy.add(new Entity(e));
        }
        return decoy;
    }

    public ArrayList<Entity> getPlayerParty() {
        ArrayList<Entity> decoy = new ArrayList<Entity>();
        for (Entity e:playerParty) {
            decoy.add(new Entity(e));
        }
        return decoy;
    }


    public void addHumanPieces(){
        for (int a = 0; a < 3; a++) {
            count = count + 1;
            Entity hPiece = new Entity(1, 0, 4, 1, 1, 5);
            humanPieces.add(new Entity(hPiece));
        }
    }

    public void addAIPieces(){
        for (int b = 0; b < level.getNumOfEnemies(); b++) {
            count = count + 1;
            Entity ePiece = new Entity(1, 0, 2, 2, 1, 5);
            aiPieces.add(new Entity(ePiece));

        }
    }
    public void addtoPlayerParty(int index)
    {
        playerParty.add(new Entity(humanPieces.get(index)));
    }

    public void addtoEntityParty()
    {
        for (int b = 0; b < aiPieces.size(); b++) 
        {
            aiParty.add(new Entity(aiPieces.get(b)));

        }
    }
    
}