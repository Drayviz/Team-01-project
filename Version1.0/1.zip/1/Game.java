import java.util.Scanner;
import java.util.ArrayList;
import java.util.Random;

public class Game {
    private HumanPlayer human;
    private AIPlayer ai;
    private GameState gameState;
    private Map map;
    private MapInfo level;
    private Pieces pieceLists;
    private int count;
    private int turncounter;
    private int gamedone;
    Random r = new Random();

   
    public Pieces getPieceLists() 
    {
        return pieceLists;
    }

    public void mapEditor()
    {   
        Scanner userinput = new Scanner(System.in);
        int doneindicator = 0;
        String fileinput;
        int inputt;
        int inputt2;
        int inputt3;
        while (doneindicator == 0)
        {   
            System.out.println("1: Create New Map");
            System.out.println("2: Load Existing Map");
            System.out.println("3: Exit");

            inputt = userinput.nextInt();
            if(inputt == 1)
            {
                System.out.println("please indicate dimensions and type");
                inputt = userinput.nextInt();
                inputt2 = userinput.nextInt();

                map = new Map(inputt, inputt2);
            }

            else if(inputt == 2)
            {
                System.out.println("please indicate file name");
                fileinput = userinput.nextLine();

                map.loadMap(fileinput);
            }

            else if(inputt == 3)
            {
                doneindicator = 1;
            }

        while(doneindicator == 0)
            {
                System.out.println("1: Edit Terrain");
                System.out.println("999: Save and Exit");
                inputt = userinput.nextInt();

                if(inputt == 1)
                {   
                    map.displayMap();
                    System.out.println("Set Terrain: Location, Slot, What you want (put space between numbers without comma)");
                    inputt = userinput.nextInt();
                    inputt2 = userinput.nextInt();
                    inputt3 = userinput.nextInt();
                    map.setState(inputt,inputt2,inputt3);


                }
                else if(inputt == 999)
                {
                    doneindicator = 1;
                } 

            }

        }
        userinput.close();
    }
    public void initializemap(String filename)
    {
        map.loadMap(filename);
        level = map.getMapinfo();
        turncounter = level.getTurns();

    }

    public void initializepieces()
    {
        addAIPieces();
        addHumanPieces();
        ddtoEntityParty();
        



    }


    public void placeHumanPieces() {
        boolean done = false;
        Scanner input = new Scanner(System.in);
        for (int i = 0; i < playerParty().size(); i++)  
        {
            while(done == false)
            {
                System.out.println("Where would you like to place your pieces? ");
                map.displayMap(); //so they can see the board
                int place = input.nextInt();
                if(map.getPiece(place) == 0)
                    {
                    done = true;
                    map.setState(place, 1, count); //Placing the entity itself in the <piece> index of the map
                    }
            }
        }
        input.close();
    }

    
    //THIS IS TEMPORARY. THIS IS JUST THE EASIEST WAY TO PLACE AI PIECES; WE WILL PLACE THEM STRATEGICALLY IN THE FUTURE
    public void placeAIPieces() 
    {
        for (int i = 0; i < getAIParty().size(); i++) 
        {
            map.setState(r.nextInt((map.getDimensions() * map.getDimensions()) - ( map.getDimensions() * map.getDimensions()) - (map.getDimensions() * 2)) + ( map.getDimensions() * map.getDimensions() - map.getDimensions() * 2), 1, count);
            //indicating that on that piece of the map, there is an enemy piece
        }
    }
    

    public void setup() 
    {
        System.out.println("Ram Ramch 0!");
        if (level.getTurns() == turncounter) //only runs when it's the first turn
        {               
            ArrayList<Entity> humanPieces = pieceLists.getHumanPieces();
            ArrayList<Entity> aiPieces = pieceLists.getAIPieces();

            GameState game = new GameState(map);
        }  
    }


    public void play() {
        while (turncounter > 0 && gamedone == 1) {
            map.displayMap();
            System.out.println("==========AI TURN===============");
            ai.getTurn();
            //GameState gameState = new GameState(map);
            map.displayMap();
            System.out.println("==============HUMAN TURN==============");
            human.getTurn();
            //return gameState = new GameState(map);
            turncounter = turncounter - 1;
            gamedone = hasWon();
        }
            if (gamedone == 1 || gamedone == 3) {
                System.out.println("==================CONGRATULATIONS!================");
            }
            else {
                System.out.println("==============GAME OVER=========================");
            }
    }

    public static void main(String[] args) {
        Game game = new Game();
        game.setup();
        game.play();
    }

}



/* Note: this enitre code was built on the assumption that each Array within each coordinate
in the ArrayList map assumes that the parameters are (simpleReference, typeOfPiece, ...)  */