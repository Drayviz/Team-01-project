public class Weapon extends Physics
{
    private Map map = super.getMap();
    private int damage;
    private int projectile;
    private int knockback;
    private String prefab;




}