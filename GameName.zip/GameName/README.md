# Team-01-project


# Description:
Our project goal is to deliver an adventure game experience like that of Into the Breach. Users will be dropped into a hub world where they are able to pick their level, party, and party gear and must complete a set of progressively harder levels until they reach a final boss.

# DEMO1 
To access the work that has been completed for Demo 1 on Feburary 26, 2019. A zipfile labeled Demo1.zip will be on the repository. Files include: Entity.java, Game.java, GameState.java, HumanPlaer.java, Map.java, MapClass.java, Pieces.java, and Turn.java

# How to compile and run Demo1
Download the GameName.zip and compile Game.java and then run Game



