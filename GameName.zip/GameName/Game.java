import java.util.Scanner;
import java.util.ArrayList;
import java.util.Random;

public class Game {
    private HumanPlayer human;
    private AIPlayer ai;
    private GameState gameState;
    private Map map = new Map();
    private MapInfo level = new MapInfo();
    private Pieces pieceLists = new Pieces();
    private int count;
    private int turncounter;
    private int gamedone = 1;
    Random r = new Random();

    public Map getMap()
    {   
        return new Map(map);
    }
   
    public Pieces getPieceLists() 
    {
        return new Pieces(pieceLists);
    }

    public void mapEditor()
    {   
        Scanner userinput = new Scanner(System.in);
        int doneindicator = 0;
        String fileinput;
        int inputt;
        int inputt2;
        int inputt3;
        int done2 = 0;
        while (doneindicator == 0)
        {   
            done2 = 0;
            System.out.println("===============");
            System.out.println("1: Create New Map");
            System.out.println("2: Load Existing Map");
            System.out.println("3: Exit");
            System.out.println("=================");

            inputt = userinput.nextInt();
            userinput.nextLine();
            if(inputt == 1)
            {
                System.out.println("========please indicate dimensions and type=========");
                inputt = userinput.nextInt();
                inputt2 = userinput.nextInt();
                System.out.println("==========================");
              

                map = new Map(inputt, inputt2);

                while(done2 == 0)
                {
                map.displayMap();
                System.out.println("\n =============================");
                System.out.println("1: Edit Terrain");
                System.out.println("999: Save and Go back to main menu");
                //System.out.println("2: Edit Settings");
                System.out.println("==========================");
                inputt = userinput.nextInt();
                userinput.nextLine();
                

                if(inputt == 1)
                {   
                    map.displayMap();
                    System.out.println("\n ==Set Terrain: Location, Slot, What you want (put space between numbers without comma)==\n");
                    inputt = userinput.nextInt();
                    inputt2 = userinput.nextInt();
                    inputt3 = userinput.nextInt();
                    map.setState(inputt,inputt2,inputt3);
                    System.out.println("==========================");
            


                }
                else if(inputt == 999)
                {   
                    System.out.print("What would you like to name it?");
                    String filename = userinput.nextLine();
                    map.saveMap(filename);
                    done2 = 1;
                }
                
                 

            }
            }

            else if(inputt == 2)
            {
                System.out.println("please indicate file name");
                fileinput = userinput.nextLine();

                map.loadMap(fileinput);
            }

            else if(inputt == 3)
            {
                doneindicator = 1;
            }
                

        }
        userinput.close();
    }
    // public void initializemap()
    // {
    //     map.loadMap(filename);
    //     level = map.getMapinfo();
    //     turncounter = level.getTurns();

    // }

    public void initializepieces()
    {   
        for(int i = 0; i < 3; i ++)
        {
            pieceLists.addAIPieces();
            pieceLists.addHumanPieces();
            pieceLists.addtoEntityParty();
            pieceLists.addtoPlayerParty(i);
        } 
    }

    public void placeHumanPieces() {
        boolean done = false;
        Scanner input = new Scanner(System.in);
        for (int i = 0; i < pieceLists.getPlayerParty().size(); i++)  
        {
            while(done == false)
            {
                System.out.println("Where would you like to place your pieces? ");
                map.displayMap(); //so they can see the board
                int place = input.nextInt();
                if(map.getPiece(place) == 0)
                    {
                    done = true;
                    map.setState(place, 1, count); //Placing the entity itself in the <piece> index of the map
                    }
            }
        }
        input.close();
    }

    
    //THIS IS TEMPORARY. THIS IS JUST THE EASIEST WAY TO PLACE AI PIECES; WE WILL PLACE THEM STRATEGICALLY IN THE FUTURE
    public void placeAIPieces() 
    {
        for (int i = 0; i < pieceLists.getAIParty().size(); i++) 
        {
            map.setState(r.nextInt((map.getDimensions() * map.getDimensions()) - ( map.getDimensions() * map.getDimensions()) - (map.getDimensions() * 2)) + ( map.getDimensions() * map.getDimensions() - map.getDimensions() * 2), 1, count);
            //indicating that on that piece of the map, there is an enemy piece
        }
    }
    

    public void setup() 
    {
        System.out.println("Welcome to Ram Ramch 0!");
        if (level.getTurns() == turncounter) //only runs when it's the first turn
        {   
            //initializemap(filename);
            this.initializepieces();   
            gameState = new GameState(map,level,pieceLists);
            ai = new AIPlayer();
            human = new HumanPlayer();
        }  
    }


    public void play() {
        while (gamedone == 1) {
            map.displayMap();
            System.out.println("==========AI TURN===============");
            ai.getEnemyTurn();
            //GameState gameState = new GameState(map);
            map.displayMap();
            System.out.println("==============HUMAN TURN==============");
            human.getTurn();
            //return gameState = new GameState(map);
            turncounter = turncounter - 1;
            gamedone = gameState.hasWon();
        }
            if (gamedone == 1 || gamedone == 3) {
                System.out.println("==================CONGRATULATIONS!================");
            }
            else {
                System.out.println("==============GAME OVER=========================");
            }
    }


public static void main(String[] args) {
    Game game = new Game();
    game.mapEditor();
    game.setup();
    game.play();
}
}



/* Note: this enitre code was built on the assumption that each Array within each coordinate
in the ArrayList map assumes that the parameters are (simpleReference, typeOfPiece, ...)  */