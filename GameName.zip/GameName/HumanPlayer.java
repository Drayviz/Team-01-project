import java.util.Scanner;
import java.util.ArrayList;


public class HumanPlayer extends GameState{
    private ArrayList<Entity> humanPieces = super.getPieceLists().getPlayerParty();
    private ArrayList<Entity> masterlist = super.getPieceLists().getMasterList();
    private Map map = super.getMap();

    HumanPlayer()
    {

    }


    /* This is a big boy. I'm gonna comment throughout... */
    public void getTurn() {
        int count = -1; //For aesthetic, just to keep track of which piece is being used
        Scanner input = new Scanner(System.in);
        for (Entity e:humanPieces) {
            count += 1;
            int startLocation = map.getPieceLocation(count);
            int ap = e.getAP(); //getting ap
            while (ap > 0) {
                System.out.print("For piece " + count + " would you like to move or attack? Type \"M\" for the former or \"A\" for the latter. ");
                String move = input.nextLine();
                while (move != "M" && move != "A") { //Error catching
                    System.out.println("Invalid answer.");
                    System.out.print("For piece " + count + " would you like to move or attack? Type \"M\" for the former or \"A\" for the latter. ");
                    move = input.nextLine();
                }
                if(move == "M") 
                {
                    boolean viable = false; //doesn't become true until a turn has been made
                    while (viable == false) { //thus, as long as a turn hasn't been made, this keeps on going
                        map.displayMap();
                        System.out.print("Where would you like to move? "); 
                        int end = input.nextInt();  //creating new Turn object to allow for move to be made
                        viable = super.isValidMove(startLocation, end,e); //first, checking to see if move is valid
                        if (viable) { 
                            map.moveState(startLocation, end);
                            ap = ap - 1; //ap is reduced
                            super.update(); //when all is g, the move is made and a map is returned, which is updated as the new map
                            
                        }
                    }
                }
                /* Same concept as (action == "M") */
                else {
                    boolean viable2 = false;
                    while (viable2 == false) {
                        map.displayMap();
                        System.out.print("Which space is your target standing on? ");
                        int target = input.nextInt();
                        viable2 = super.isValidAtk(startLocation, target,e);
                        if (viable2) {
                            e.setHp(masterlist.get(target));
                            ap = ap - 2;
                            super.update();
                            
                        } 
                    }
                }
            }
        }
    }
}