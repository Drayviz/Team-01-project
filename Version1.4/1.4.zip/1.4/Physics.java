public class Physics
{
    Physics()
    {

    }

}