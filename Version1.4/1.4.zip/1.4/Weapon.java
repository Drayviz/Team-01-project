public class Weapon extends Physics
{
    //private Map map = super.getMap();
    private int damage;
    private int projectile;
    private int knockback;
    private int prefab;

    Weapon()
    {

    }
    Weapon(int prefab)
    {

    }
    Weapon(Weapon w)
    {

    }


}