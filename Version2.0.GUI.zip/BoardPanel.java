import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.stage.Stage;
import javafx.scene.control.Label;
import javafx.scene.text.Font;
import javafx.scene.paint.Color;
import javafx.scene.layout.VBox;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import java.util.ArrayList;

public class BoardPanel extends Application {
    private Map map;
    private MetaGame startGame = new MetaGame();
    private Game game = new Game();
    private Pieces pieceLists = new Pieces();

    private Label toPlayer = new Label("Welcome!");
    private int gridCount = 0;
    private String submessage = "EMPTY";

	@Override
    public void start(Stage primaryStage) {
        
		BorderPane root = new BorderPane(); //BorderPane is the main layout
        VBox topSection = new VBox(0);
        HBox underTop = new HBox();
        GridPane grid = new GridPane();
        
        toPlayer.setFont(Font.font("Courier New", 18));
        //toPlayer.setTextFill(Color.WHITE);
        toPlayer.setAlignment(Pos.CENTER);

        Button endTurn = new Button("End Turn");
        Button undoMove = new Button("Undo Move");
        Button viewParty = new Button("View party");
        Button viewEnemies = new Button("View enemies");
        Button attackOrder = new Button("Attack Order");

        HBox rightButton = new HBox(attackOrder);
        rightButton.setAlignment(Pos.CENTER_RIGHT);
        HBox.setHgrow(rightButton, Priority.ALWAYS);

        underTop.getChildren().addAll(endTurn, undoMove, viewParty, viewEnemies, rightButton);
        underTop.setPadding(new Insets(2));

        topSection.getChildren().addAll(toPlayer, underTop);

        grid.setVgap(20);
        grid.setHgap(20);
        grid.setAlignment(Pos.CENTER);

        //Initial map creation
        //ArrayList<Button> gridButtons = new ArrayList<Button>();
        gridCount = 0;
        for(int row = 0; row < 8; row++) {
            for(int col = 0; col < 8; col++) {
                gridCount++;
                grid.setStyle("-fx-background-color: GREEN;");
                String message = gridCount + ", " + submessage;
                Button boardButton = new Button(message);
                grid.add(boardButton, col, row);
                boardButton.setOnAction(new EventHandler<ActionEvent>() {
                    @Override
                    public void handle(ActionEvent event) {
                        int piecesPlaced = 0;
                        if (game.getTurnCounter() == 0 && pieceLists.getPlayerParty().size()) {
                            for (int i = 0; i < pieceLists.getPlayerParty().size(); i++) {
                                if (gridCount < 41) {
                                    map.setState(gridCount, 1, piecesPlaced); //Placing the entity itself in the <piece> index of the map
                                    piecesPlaced++;
                                    submessage = "PIECE " + piecesPlaced;
                                }
                            }
                        }
                    }
                });
            }
        }

        topSection.setPadding(new Insets(10, 30, 30, 30));
        topSection.setSpacing(5);

        root.setPadding(new Insets(30,30,30,30));
        root.setCenter(grid);     
		root.setTop(topSection);
        //root.setStyle("-fx-background-color: BLACK;");

		Scene scene = new Scene(root, 640, 480);
	    primaryStage.setTitle("Planet Invaders");
	    primaryStage.setScene(scene);
        primaryStage.show();

        //C O M M U N I C A T I O N
        gamePlaying();

        //E V E N T H A N D L I N G
        /* This is for the viewParty button */
        viewParty.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                String forDisplay = "Party: ";
                for(Entity e:pieceLists.getPlayerParty()) {
                    forDisplay = forDisplay + e.getName() + " (atk: " + e.getAtk() + ",hp: " + e.getHp() + ",mvt: " + e.getMovement() + ") ";
                    //forDisplay = forDisplay + "1";
                }
                toPlayer.setText(forDisplay);
            }
        });
        endTurn.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                game.setTurnCounter();
                System.out.println(game.getTurnCounter());
            }
        });
    }

    public void gamePlaying() {
        this.game = startGame.startgame("five");
        this.pieceLists = game.getPieces();
        this.map = game.getMap();
        if (game.getTurnCounter() == 0) {
            toPlayer.setText("Place your pieces! ");
        }
    }

/*    public void turn0(int buttonSelected) {

    }*/

	public static void main(String[] args) {
        launch(args);	
	}
}

/*        int count = 0;
        int dimensions = map.getDimensions();
        ArrayList<ArrayList<Integer>> proxyMap = map.getMaparray();
        for(int row = 0; row < dimensions; row++) {
            for(int col = 0; col < dimensions; col++) {
                count++;
                grid.setStyle("-fx-background-color: GREEN;");
                String submessage = "";
                ArrayList<Integer> tilearray = proxyMap.get(count - 1);
                if(tilearray.get(0) == 1 && tilearray.get(1) == 0)
                {
                    submessage = "EMPTY";
                }
                else
                {
                    submessage = tilearray.get(1)+"";
                }
                String message = count + ", " + submessage;
                grid.add(new Button(message), col, row);

            }
        }*/